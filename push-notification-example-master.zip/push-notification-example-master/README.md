# Push Notification Example

> An Example to build an application that support push notification

## Live: https://prayer-app-push-notif.firebaseapp.com/
